class Utils{
  Utils();
  ///To compare if two strings are equal.
  ///27 Spetember 2020
  bool stringEqual(String val1,String val2)=>(val1 == val2);
    ///To compare if two ints are equal.
  ///27 Spetember 2020
  bool intEqual(int val1,int val2)=>(val1 == val2);
}